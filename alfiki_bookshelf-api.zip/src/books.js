// File untuk menginisialisasi array books untuk Bookshelf API
// Alfiki Diastama Afan Firdaus

const books = []

export default books
